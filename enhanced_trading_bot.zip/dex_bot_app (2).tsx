import { useState, useEffect, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, Wallet, DollarSign, Settings, TrendingUp, TrendingDown, BarChart3 } from 'lucide-react';

const TRADING_PAIRS = [
  { id: 'ethereum', name: 'Ethereum', symbol: 'ETH', coingecko_id: 'ethereum' },
  { id: 'bitcoin', name: 'Bitcoin', symbol: 'BTC', coingecko_id: 'bitcoin' },
  { id: 'solana', name: 'Solana', symbol: 'SOL', coingecko_id: 'solana' },
  { id: 'matic', name: 'Polygon', symbol: 'MATIC', coingecko_id: 'matic-network' },
  { id: 'avalanche', name: 'Avalanche', symbol: 'AVAX', coingecko_id: 'avalanche-2' },
  { id: 'chainlink', name: 'Chainlink', symbol: 'LINK', coingecko_id: 'chainlink' }
];

export default function TradingBot() {
  const [isRunning, setIsRunning] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [account, setAccount] = useState('');
  const [selectedPair, setSelectedPair] = useState(TRADING_PAIRS[0]);
  const [prices, setPrices] = useState({});
  const [priceHistory, setPriceHistory] = useState({});
  const [signals, setSignals] = useState([]);
  const [ethBalance, setEthBalance] = useState(0);
  const [positions, setPositions] = useState({});
  const [trades, setTrades] = useState([]);
  const [walletStatus, setWalletStatus] = useState('checking');
  
  const priceBufferRef = useRef({});
  const priceIntervalRef = useRef(null);
  
  const [config, setConfig] = useState({
    bbPeriod: 20,
    bbStdDev: 2,
    macdFast: 12,
    macdSlow: 26,
    fibPeriod: 50,
    tradeAmount: 0.01,
    paperTrading: true,
    stopLossPercent: 2,
    takeProfitPercent: 5
  });

  const connectWallet = async () => {
    try {
      setWalletStatus('connecting');
      
      if (typeof window.ethereum === 'undefined') {
        setWalletStatus('not-found');
        addSignal({
          type: 'ERROR',
          pair: 'SYSTEM',
          indicator: 'Wallet',
          reason: 'No MetaMask detected. Install from metamask.io',
          time: new Date().toLocaleTimeString()
        });
        alert('MetaMask Not Found!\n\nPlease install MetaMask browser extension:\nhttps://metamask.io/download/');
        return;
      }

      setWalletStatus('requesting');
      const accounts = await window.ethereum.request({ 
        method: 'eth_requestAccounts' 
      });
      
      if (!accounts || accounts.length === 0) {
        setWalletStatus('denied');
        throw new Error('No accounts returned');
      }

      setWalletStatus('switching-network');
      try {
        await window.ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: '0x2105' }],
        });
      } catch (switchError) {
        if (switchError.code === 4902) {
          setWalletStatus('adding-network');
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [{
              chainId: '0x2105',
              chainName: 'Base',
              nativeCurrency: { name: 'Ethereum', symbol: 'ETH', decimals: 18 },
              rpcUrls: ['https://mainnet.base.org'],
              blockExplorerUrls: ['https://basescan.org']
            }]
          });
        } else {
          throw switchError;
        }
      }
      
      setAccount(accounts[0]);
      setIsConnected(true);
      setWalletStatus('connected');
      await updateBalances(accounts[0]);
      startPriceFetching();
      
      addSignal({
        type: 'INFO',
        pair: 'SYSTEM',
        indicator: 'Wallet',
        reason: `Connected: ${accounts[0].substring(0, 6)}...${accounts[0].substring(38)}`,
        time: new Date().toLocaleTimeString()
      });
    } catch (error) {
      console.error('Wallet error:', error);
      setWalletStatus('error');
      addSignal({
        type: 'ERROR',
        pair: 'SYSTEM',
        indicator: 'Wallet',
        reason: error.message || 'Connection failed',
        time: new Date().toLocaleTimeString()
      });
    }
  };

  const updateBalances = async (address) => {
    try {
      const ethBalanceHex = await window.ethereum.request({
        method: 'eth_getBalance',
        params: [address, 'latest']
      });
      setEthBalance(parseInt(ethBalanceHex, 16) / 1e18);
    } catch (error) {
      console.error('Balance error:', error);
    }
  };

  const fetchPrices = async () => {
    try {
      const ids = TRADING_PAIRS.map(p => p.coingecko_id).join(',');
      const response = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd`);
      const data = await response.json();
      
      const newPrices = {};
      const timestamp = new Date().toLocaleTimeString();
      
      TRADING_PAIRS.forEach(pair => {
        const price = data[pair.coingecko_id]?.usd;
        if (price && price > 0) {
          newPrices[pair.id] = price;
          
          setPriceHistory(prev => ({
            ...prev,
            [pair.id]: [...(prev[pair.id] || []), { time: timestamp, price }].slice(-100)
          }));
          
          if (!priceBufferRef.current[pair.id]) {
            priceBufferRef.current[pair.id] = [];
          }
          priceBufferRef.current[pair.id].push(price);
          if (priceBufferRef.current[pair.id].length > 200) {
            priceBufferRef.current[pair.id] = priceBufferRef.current[pair.id].slice(-200);
          }
        }
      });
      
      setPrices(newPrices);
    } catch (error) {
      console.error('Price fetch error:', error);
    }
  };

  const startPriceFetching = () => {
    fetchPrices();
    priceIntervalRef.current = setInterval(fetchPrices, 10000);
  };

  const stopPriceFetching = () => {
    if (priceIntervalRef.current) {
      clearInterval(priceIntervalRef.current);
    }
  };

  const calculateSMA = (data, period) => {
    if (data.length < period) return null;
    const slice = data.slice(-period);
    return slice.reduce((sum, val) => sum + val, 0) / period;
  };

  const calculateStdDev = (data, period, sma) => {
    if (data.length < period) return null;
    const slice = data.slice(-period);
    const variance = slice.reduce((sum, val) => sum + Math.pow(val - sma, 2), 0) / period;
    return Math.sqrt(variance);
  };

  const calculateBollingerBands = (prices) => {
    const sma = calculateSMA(prices, config.bbPeriod);
    if (!sma) return null;
    const stdDev = calculateStdDev(prices, config.bbPeriod, sma);
    return {
      upper: sma + (stdDev * config.bbStdDev),
      middle: sma,
      lower: sma - (stdDev * config.bbStdDev)
    };
  };

  const calculateEMA = (data, period) => {
    if (data.length < period) return null;
    const multiplier = 2 / (period + 1);
    let ema = calculateSMA(data.slice(0, period), period);
    for (let i = period; i < data.length; i++) {
      ema = (data[i] - ema) * multiplier + ema;
    }
    return ema;
  };

  const calculateMACD = (prices) => {
    if (prices.length < config.macdSlow) return null;
    const emaFast = calculateEMA(prices, config.macdFast);
    const emaSlow = calculateEMA(prices, config.macdSlow);
    if (!emaFast || !emaSlow) return null;
    const macdLine = emaFast - emaSlow;
    return { macd: macdLine, signal: macdLine * 0.9, histogram: macdLine * 0.1 };
  };

  const addSignal = (signal) => {
    setSignals(prev => [signal, ...prev].slice(0, 30));
  };

  const checkStopLossAndTakeProfit = () => {
    Object.keys(positions).forEach(pairId => {
      const position = positions[pairId];
      const currentPrice = prices[pairId];
      if (!position || !currentPrice) return;
      
      const entryPrice = position.entryPrice;
      const currentPnLPercent = ((currentPrice - entryPrice) / entryPrice) * 100;
      
      const pair = TRADING_PAIRS.find(p => p.id === pairId);
      
      if (currentPnLPercent <= -config.stopLossPercent) {
        const reason = `Stop-loss at ${config.stopLossPercent}% loss`;
        addSignal({
          type: 'SELL',
          pair: pair.symbol,
          indicator: 'Stop-Loss',
          reason: reason,
          time: new Date().toLocaleTimeString()
        });
        executeTrade(pair, { type: 'SELL', reason: reason });
      }
      
      if (currentPnLPercent >= config.takeProfitPercent) {
        const reason = `Take-profit at ${config.takeProfitPercent}% gain`;
        addSignal({
          type: 'SELL',
          pair: pair.symbol,
          indicator: 'Take-Profit',
          reason: reason,
          time: new Date().toLocaleTimeString()
        });
        executeTrade(pair, { type: 'SELL', reason: reason });
      }
    });
  };

  const generateSignals = () => {
    TRADING_PAIRS.forEach(pair => {
      const pairPrices = priceBufferRef.current[pair.id];
      if (!pairPrices || pairPrices.length < config.macdSlow) return;
      
      const currentPrice = prices[pair.id];
      if (!currentPrice) return;
      
      const bb = calculateBollingerBands(pairPrices);
      const macd = calculateMACD(pairPrices);
      
      const newSignals = [];
      
      if (bb && currentPrice <= bb.lower) {
        newSignals.push({
          type: 'BUY',
          pair: pair.symbol,
          indicator: 'Bollinger Bands',
          reason: 'Price at lower band - oversold',
          time: new Date().toLocaleTimeString()
        });
      } else if (bb && currentPrice >= bb.upper) {
        newSignals.push({
          type: 'SELL',
          pair: pair.symbol,
          indicator: 'Bollinger Bands',
          reason: 'Price at upper band - overbought',
          time: new Date().toLocaleTimeString()
        });
      }
      
      if (macd && macd.histogram > 0 && macd.macd > macd.signal) {
        newSignals.push({
          type: 'BUY',
          pair: pair.symbol,
          indicator: 'MACD',
          reason: 'Bullish momentum',
          time: new Date().toLocaleTimeString()
        });
      } else if (macd && macd.histogram < 0 && macd.macd < macd.signal) {
        newSignals.push({
          type: 'SELL',
          pair: pair.symbol,
          indicator: 'MACD',
          reason: 'Bearish momentum',
          time: new Date().toLocaleTimeString()
        });
      }
      
      if (newSignals.length > 0) {
        newSignals.forEach(signal => addSignal(signal));
        if (isRunning) {
          executeTrade(pair, newSignals[0]);
        }
      }
    });
  };

  const executeTrade = async (pair, signal) => {
    const currentPrice = prices[pair.id];
    const position = positions[pair.id];
    
    if (signal.type === 'BUY' && position) return;
    if (signal.type === 'SELL' && !position) return;

    if (signal.type === 'BUY') {
      const newPosition = {
        entryPrice: currentPrice,
        amount: config.tradeAmount,
        entryTime: new Date().toLocaleTimeString(),
        stopLoss: currentPrice * (1 - config.stopLossPercent / 100),
        takeProfit: currentPrice * (1 + config.takeProfitPercent / 100)
      };
      
      setPositions(prev => ({ ...prev, [pair.id]: newPosition }));
      
      setTrades(prev => [{
        type: 'BUY',
        pair: pair.symbol,
        price: currentPrice,
        amount: config.tradeAmount,
        time: new Date().toLocaleTimeString(),
        reason: signal.reason,
        status: config.paperTrading ? 'Paper' : 'Live'
      }, ...prev]);
    } else {
      const profit = (currentPrice - position.entryPrice) * position.amount;
      const profitPercent = ((currentPrice - position.entryPrice) / position.entryPrice) * 100;
      
      setTrades(prev => [{
        type: 'SELL',
        pair: pair.symbol,
        price: currentPrice,
        amount: position.amount,
        time: new Date().toLocaleTimeString(),
        profit: profit,
        profitPercent: profitPercent,
        reason: signal.reason,
        status: config.paperTrading ? 'Paper' : 'Live'
      }, ...prev]);
      
      setPositions(prev => {
        const newPos = { ...prev };
        delete newPos[pair.id];
        return newPos;
      });
    }
  };

  useEffect(() => {
    if (isRunning && Object.keys(prices).length > 0) {
      const interval = setInterval(() => {
        generateSignals();
        checkStopLossAndTakeProfit();
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isRunning, prices]);

  useEffect(() => {
    if (typeof window.ethereum !== 'undefined') {
      setWalletStatus('available');
    } else {
      setWalletStatus('not-found');
    }
    return () => stopPriceFetching();
  }, []);

  const currentPosition = positions[selectedPair.id];
  const currentPrice = prices[selectedPair.id] || 0;
  const currentHistory = priceHistory[selectedPair.id] || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white p-4">
      <div className="max-w-7xl mx-auto space-y-4">
        <div className="bg-slate-800/50 backdrop-blur rounded-lg p-4 border border-slate-700">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Activity className="w-6 h-6 text-purple-400" />
              <h1 className="text-2xl font-bold">Multi-Pair DEX Bot</h1>
            </div>
            {isConnected && (
              <span className="text-sm text-green-400">
                {account.substring(0, 6)}...{account.substring(38)}
              </span>
            )}
          </div>

          {!isConnected ? (
            <div>
              <button 
                onClick={connectWallet}
                className="w-full bg-purple-600 hover:bg-purple-700 p-6 rounded-xl text-center border-2 border-purple-400 transition-all"
              >
                <Wallet className="w-12 h-12 mx-auto mb-3" />
                <div className="text-xl font-bold mb-1">Connect MetaMask</div>
                <div className="text-sm text-purple-200">Required to start trading</div>
              </button>
              
              <div className="mt-3 p-3 bg-slate-700/50 rounded text-sm">
                <div className="font-semibold mb-2">Status:</div>
                {walletStatus === 'not-found' && (
                  <div className="text-red-400">❌ MetaMask not found - Install from metamask.io</div>
                )}
                {walletStatus === 'available' && <div className="text-green-400">✓ MetaMask detected</div>}
                {walletStatus === 'connecting' && <div className="text-blue-400">⏳ Connecting...</div>}
                {walletStatus === 'connected' && <div className="text-green-400">✓ Connected!</div>}
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => { setIsConnected(false); setAccount(''); stopPriceFetching(); }}
                  className="bg-slate-600 hover:bg-slate-700 p-4 rounded-lg font-semibold transition-all"
                >
                  Disconnect
                </button>
                <button
                  onClick={() => setIsRunning(!isRunning)}
                  className={`p-4 rounded-lg font-semibold transition-all ${isRunning ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}`}
                >
                  {isRunning ? '⏸ STOP BOT' : '▶ START BOT'}
                </button>
              </div>
              
              <div className="bg-slate-700/50 p-3 rounded">
                <div className="text-xs text-slate-400 mb-2">Select Trading Pair</div>
                <div className="grid grid-cols-3 gap-2">
                  {TRADING_PAIRS.map(pair => (
                    <button
                      key={pair.id}
                      onClick={() => setSelectedPair(pair)}
                      className={`p-2 rounded text-sm font-semibold transition-all ${
                        selectedPair.id === pair.id
                          ? 'bg-purple-600 text-white'
                          : 'bg-slate-600 hover:bg-slate-500 text-slate-200'
                      }`}
                    >
                      {pair.symbol}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
            <div className="bg-slate-700/50 p-3 rounded">
              <div className="text-xs text-slate-400">{selectedPair.symbol} Price</div>
              <div className="text-lg font-bold">${currentPrice > 0 ? currentPrice.toLocaleString() : '--'}</div>
            </div>
            <div className="bg-slate-700/50 p-3 rounded">
              <div className="text-xs text-slate-400">Network</div>
              <div className="text-lg font-bold">Base</div>
            </div>
            <div className="bg-slate-700/50 p-3 rounded">
              <div className="text-xs text-slate-400">Balance</div>
              <div className="text-lg font-bold">{ethBalance.toFixed(4)} ETH</div>
            </div>
            <div className="bg-slate-700/50 p-3 rounded">
              <div className="text-xs text-slate-400">Mode</div>
              <div className="text-lg font-bold">{config.paperTrading ? '📄 Paper' : '🔴 Live'}</div>
            </div>
          </div>
        </div>

        {currentPosition && (
          <div className="bg-green-900/30 backdrop-blur rounded-lg p-4 border border-green-700">
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Active Position: {selectedPair.symbol}
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-sm">
              <div>
                <div className="text-xs text-green-300">Entry</div>
                <div className="font-semibold">${currentPosition.entryPrice.toFixed(2)}</div>
              </div>
              <div>
                <div className="text-xs text-green-300">Current</div>
                <div className="font-semibold">${currentPrice.toFixed(2)}</div>
              </div>
              <div>
                <div className="text-xs text-green-300">Amount</div>
                <div className="font-semibold">{currentPosition.amount.toFixed(4)} {selectedPair.symbol}</div>
              </div>
              <div>
                <div className="text-xs text-green-300">Stop Loss</div>
                <div className="font-semibold text-red-400">${currentPosition.stopLoss.toFixed(2)}</div>
              </div>
              <div>
                <div className="text-xs text-green-300">Take Profit</div>
                <div className="font-semibold text-green-400">${currentPosition.takeProfit.toFixed(2)}</div>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-green-700">
              <div className={`text-lg font-bold ${currentPrice >= currentPosition.entryPrice ? 'text-green-400' : 'text-red-400'}`}>
                P&L: ${((currentPrice - currentPosition.entryPrice) * currentPosition.amount).toFixed(2)} 
                ({(((currentPrice - currentPosition.entryPrice) / currentPosition.entryPrice) * 100).toFixed(2)}%)
              </div>
            </div>
          </div>
        )}

        {currentHistory.length > 0 && (
          <div className="bg-slate-800/50 backdrop-blur rounded-lg p-4 border border-slate-700">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              {selectedPair.name} Price Chart
            </h3>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={currentHistory.slice(-50)}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="time" stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <YAxis stroke="#94a3b8" domain={['auto', 'auto']} />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }} />
                <Line type="monotone" dataKey="price" stroke="#a855f7" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        <div className="bg-slate-800/50 backdrop-blur rounded-lg p-4 border border-slate-700">
          <h3 className="font-semibold mb-3">Trading Signals</h3>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {signals.length === 0 ? (
              <p className="text-slate-400 text-sm">No signals yet. Connect wallet and start the bot.</p>
            ) : (
              signals.map((signal, idx) => (
                <div 
                  key={idx}
                  className={`p-3 rounded border text-sm ${
                    signal.type === 'BUY' ? 'bg-green-900/20 border-green-700' 
                    : signal.type === 'SELL' ? 'bg-red-900/20 border-red-700'
                    : 'bg-blue-900/20 border-blue-700'
                  }`}
                >
                  <div className="flex justify-between">
                    <div>
                      <div className="font-semibold">
                        {signal.type === 'BUY' ? '📈' : signal.type === 'SELL' ? '📉' : 'ℹ️'} {signal.type} {signal.pair} - {signal.indicator}
                      </div>
                      <div className="text-xs text-slate-300">{signal.reason}</div>
                    </div>
                    <div className="text-xs text-slate-400">{signal.time}</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur rounded-lg p-4 border border-slate-700">
          <h3 className="font-semibold mb-3">Recent Trades</h3>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {trades.length === 0 ? (
              <p className="text-slate-400 text-sm">No trades yet.</p>
            ) : (
              trades.map((trade, idx) => (
                <div key={idx} className="p-3 bg-slate-700/50 rounded text-sm">
                  <div className="flex justify-between">
                    <div className="flex-1">
                      <span className={`font-semibold ${trade.type === 'BUY' ? 'text-green-400' : 'text-red-400'}`}>
                        {trade.type} {trade.pair}
                      </span>
                      <span className="text-slate-300 ml-2">
                        {trade.amount.toFixed(4)} @ ${trade.price.toFixed(2)}
                      </span>
                      {trade.profit !== undefined && (
                        <span className={`ml-2 font-semibold ${trade.profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {trade.profit >= 0 ? '+' : ''}{trade.profit.toFixed(2)} ({trade.profitPercent.toFixed(2)}%)
                        </span>
                      )}
                      <span className="text-xs text-slate-500 ml-2">[{trade.status}]</span>
                    </div>
                    <span className="text-xs text-slate-400">{trade.time}</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-1">{trade.reason}</div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur rounded-lg p-4 border border-slate-700">
          <div className="flex items-center gap-2 mb-4">
            <Settings className="w-5 h-5" />
            <h3 className="font-semibold">Configuration</h3>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs text-slate-400">Trade Amount</label>
              <input
                type="number"
                step="0.001"
                value={config.tradeAmount}
                onChange={(e) => setConfig({...config, tradeAmount: parseFloat(e.target.value)})}
                className="w-full bg-slate-700 text-white rounded px-2 py-1 text-sm"
                disabled={isRunning}
              />
            </div>
            <div>
              <label className="text-xs text-slate-400">Stop Loss %</label>
              <input
                type="number"
                value={config.stopLossPercent}
                onChange={(e) => setConfig({...config, stopLossPercent: parseFloat(e.target.value)})}
                className="w-full bg-slate-700 text-white rounded px-2 py-1 text-sm"
                disabled={isRunning}
              />
            </div>
            <div>
              <label className="text-xs text-slate-400">Take Profit %</label>
              <input
                type="number"
                value={config.takeProfitPercent}
                onChange={(e) => setConfig({...config, takeProfitPercent: parseFloat(e.target.value)})}
                className="w-full bg-slate-700 text-white rounded px-2 py-1 text-sm"
                disabled={isRunning}
              />
            </div>
            <div>
              <label className="flex items-center gap-2 mt-5">
                <input
                  type="checkbox"
                  checked={config.paperTrading}
                  onChange={(e) => setConfig({...config, paperTrading: e.target.checked})}
                  disabled={isRunning}
                  className="w-4 h-4"
                />
                <span className="text-sm">Paper Trading</span>
              </label>
            </div>
          </div>

          <div className="mt-4 p-3 bg-yellow-900/20 border border-yellow-700 rounded">
            <p className="text-sm text-yellow-200">
              ⚠️ <strong>Warning:</strong> Always test with Paper Trading enabled first! Real trading involves risk.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}