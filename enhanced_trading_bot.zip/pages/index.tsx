import EnhancedTradingBot from '../enhanced_trading_bot';
import '../styles/globals.css';

export default function Home() {
  return (
    <div>
      <EnhancedTradingBot />
    </div>
  );
}